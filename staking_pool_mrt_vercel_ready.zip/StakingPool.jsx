
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ethers } from 'ethers';

const CONTRACT_ADDRESS = '0x6520099caF3e591531ADBcb36B3FF491fc86e4B6';
const REWARD_RATE = 10000;

// ABI sementara, pastikan diganti dengan ABI asli
const ABI = [
  'function stake() public payable',
  'function withdraw(uint256 amount) public',
  'function unstake(uint256 amount) public'
];

const MEGA_ETH_PARAMS = {
  chainId: '0x12345',
  chainName: 'Mega ETH Network',
  rpcUrls: ['https://rpc.megaeth.org'],
  blockExplorerUrls: ['https://explorer.megaeth.org'],
  nativeCurrency: {
    name: 'MegaETH',
    symbol: 'METH',
    decimals: 18,
  },
};

const StakingPool = () => {
  const [stakedAmount, setStakedAmount] = useState(0);
  const [rewards, setRewards] = useState(0);
  const [inputValue, setInputValue] = useState('');
  const [walletAddress, setWalletAddress] = useState(null);
  const [provider, setProvider] = useState(null);
  const [contract, setContract] = useState(null);

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  return (
    <div style={{ maxWidth: '400px', margin: 'auto', padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <img src="logo.png" alt="MRT Logo" style={{ display: 'block', margin: 'auto', width: '200px', marginBottom: '1rem' }} />
      <h1 style={{ textAlign: 'center' }}>Staking Pool Liquidity (Mega ETH)</h1>
      <input
        type="number"
        value={inputValue}
        onChange={handleInputChange}
        placeholder="Enter amount to stake (METH)"
        style={{ width: '100%', padding: '0.5rem', fontSize: '1rem', marginTop: '1rem', marginBottom: '1rem' }}
      />
    </div>
  );
};

export default StakingPool;
